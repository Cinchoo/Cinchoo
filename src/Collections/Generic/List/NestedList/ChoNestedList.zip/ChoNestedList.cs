﻿#region Header

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Copyright (c) 2009-2010 Raj Nagalingam.
 *    All rights reserved.
 *
 * This program and the accompanying materials are made available under
 * the terms of the Common Public License v1.0 which accompanies this
 * distribution.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in
 * the documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *<author>Raj Nagalingam</author>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#endregion Header

namespace Cinchoo.Core.Collections.Generic.List.NestedList
{
    #region NameSpaces

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Runtime.InteropServices;
    using System.Diagnostics;
    using System.Collections;
    using Cinchoo.Core.Exceptions;

    #endregion NameSpaces

    [Serializable]
    [ComVisible(false)]
    [DebuggerDisplay("Count = {Count}")]
    public partial class ChoNestedList<T> : IChoList<T>, ICloneable
    {
        #region Instance Data Members (Private)

        private readonly object _syncRoot = new object();
        private readonly ArrayList _innerList = new ArrayList();

		#endregion Instance Data Members (Private)

        #region Constructors

		/// <summary>
		/// Initializes a new instance of the ChoNestedList<T> class
		/// that is empty and had the default initial capacity
		/// </summary>
		public ChoNestedList()
        {
        }

		/// <summary>
		/// Initializes a new instance of the ChoNestedList<T> class
		/// that contains element copied from the passed item object.
		/// </summary>
		/// <param name="item">An object to be copied to the the new list.</param>
		public ChoNestedList(T item)
        {
            Add(item);
        }

		/// <summary>
		/// Initializes a new instance of the ChoNestedList<T> class
		/// that contains element copied from the passed list object as an element.
		/// </summary>
		/// <param name="list">A collection object to be copied as an element to the the new list.</param>
        public ChoNestedList(IList<T> list)
        {
            Add(list);
        }

		/// <summary>
		/// Initializes a new instance of the ChoNestedList<T> class
		/// that contains elements copied from the specified collection and has sufficient
		/// capacity to accommodate the number of elements copied.
		/// </summary>
		/// <param name="collection">The collection whose elements are copied to the new list.</param>
		/// <exception cref="System.ArgumentNullException">collection is null.</remarks>
		public ChoNestedList(IEnumerable<T> collection)
		{
			ChoGuard.ArgumentNotNull(collection, "collection is null");
			AddRange(collection);
		}

		/// <summary>
		/// Initializes a new instance of the ChoNestedList<T> class
		/// that contains elements copied from the specified collection and has sufficient
		/// capacity to accommodate the number of elements copied.
		/// </summary>
		/// <param name="collection">The collection whose elements are copied to the new list.</param>
		/// <exception cref="System.ArgumentNullException">collection is null.</remarks>
		public ChoNestedList(IEnumerable<IList<T>> collection)
        {
            ChoGuard.ArgumentNotNull(collection, "collection");
            AddRange(collection);
        }

        #endregion Constructors

        #region ICloneable Members

        public object Clone()
        {
            ChoNestedList<T> newNestedList = new ChoNestedList<T>();
            Clone(this, newNestedList);

            return newNestedList;
        }

		private void Clone(IEnumerable inList, IEnumerable outList)
		{
			if (inList is ChoNestedList<T>)
				inList = ((ChoNestedList<T>)inList)._innerList;

			foreach (object item in inList)
			{
				if (item == null || item is T)
				{
					if (item == null)
						AddItem(outList, item);
					else if (item is ICloneable)
						AddItem(outList, (T)((ICloneable)item).Clone());
					else
						throw new ChoNestedListException("item is not clonable object.");
				}
				else if (item is IEnumerable)
				{
					IEnumerable subOutList = null;

					if (item is ArrayList)
						subOutList = new ArrayList();
					else if (item is ChoNestedList<T>)
						subOutList = new ChoNestedList<T>();
					else if (item is List<T>)
						subOutList = new List<T>();
					else
						throw new ChoNestedListException("Unsupported list item found.");

					Clone((IEnumerable)item, subOutList);

					AddItem(outList, subOutList);
				}
				else
					throw new ChoNestedListException("Unsupported list item found.");
			}
		}

		private void AddItem(IEnumerable inList, object item)
		{
			if (inList is ArrayList)
				((ArrayList)inList).Add(item);
			else if (inList is ChoNestedList<T>)
				((ChoNestedList<T>)inList)._innerList.Add(item);
			else if (inList is List<T>)
				((List<T>)inList).Add((T)item);
			else
				throw new ChoNestedListException("Unsupported list item found.");
		}

        #endregion

        #region IChoList<T> Members

        #region Sort Overloads

        public void Sort()
        {
            throw new NotImplementedException();
        }

        public void Sort(Comparison<T> comparison)
        {
            throw new NotImplementedException();
        }

        public void Sort(IComparer<T> comparer)
        {
            throw new NotImplementedException();
        }

        public void Sort(int index, int count, IComparer<T> comparer)
        {
            throw new NotImplementedException();
        }

        #endregion Sort Overloads

        #region BinarySearch Overloads

        public int BinarySearch(T item)
        {
            T[] array = ToSortedArray();
            return Array.BinarySearch<T>(array, 0, array.Length, item);
        }

        public int BinarySearch(T item, IComparer<T> comparer)
        {
            T[] array = ToSortedArray();
            return Array.BinarySearch<T>(array, 0, array.Length, item, comparer);
        }

        public int BinarySearch(int index, int count, T item, IComparer<T> comparer)
        {
            T[] array = ToSortedArray();
            CheckRange(index, count, array.Length);
            return Array.BinarySearch<T>(array, index, count, item, comparer);
        }

        #endregion BinarySearch Overloads

        #region ToSortedArray Overloads

        public T[] ToSortedArray(Comparison<T> comparison)
        {
            T[] array = ToArray();
            Array.Sort<T>(array, comparison);
            return array;
        }

        public T[] ToSortedArray()
        {
            T[] array = ToArray();
            Array.Sort<T>(array, 0, array.Length, Comparer<T>.Default);
            return array;
        }

        public T[] ToSortedArray(IComparer<T> comparer)
        {
            T[] array = ToArray();
            Array.Sort<T>(array, 0, array.Length, comparer);
            return array;
        }

        public T[] ToSortedArray(int index, int count, IComparer<T> comparer)
        {
            T[] array = ToArray();
            CheckRange(index, count, array.Length);
            Array.Sort<T>(array, index, count, Comparer<T>.Default);
            return array;
        }

        #endregion ToSortedArray Overloads

        #region Add Overloads

        public void Add(T item)
        {
            _innerList.Add(item);
        }

        public void Add(IList<T> listItem)
        {
            ChoGuard.ArgumentNotNull(listItem, "list");

            if (listItem == this)
                throw new InvalidOperationException("Can't add same list to itself.");

            if (listItem is ChoNestedList<T>)
            {
				if (((ChoNestedList<T>)listItem).Contains(this))
					throw new InvalidOperationException("Can't add item to the list, because it'll makes circular reference.");

				if (CheckCircularReferenceExists(listItem as ChoNestedList<T>))
                    throw new InvalidOperationException("Can't add item to the list, because it'll makes circular reference.");
            }

            _innerList.Add(listItem);
        }

		private bool CheckCircularReferenceExists(ChoNestedList<T> listItem)
        {
			ChoNestedList<T>.ChoNestedCollectionListEnumerator<T> x1 = new ChoNestedList<T>.ChoNestedCollectionListEnumerator<T>(listItem);
			while (x1.MoveNext())
			{
				ChoNestedList<T>.ChoNestedCollectionListEnumerator<T> x2 = new ChoNestedList<T>.ChoNestedCollectionListEnumerator<T>(this);
				while (x2.MoveNext())
				{
					if (x2.Current == x1.Current)
						return true;
				}
			}
			
			return false;
        }

        #endregion Add Overloads

        #region AddRange Overloads

        public void AddRange(IEnumerable<T> collection)
        {
            if (collection == null) return;

            foreach (T item in collection)
                Add(item);
        }

        public void AddRange(IEnumerable<IList<T>> collection)
        {
            if (collection == null) return;

            foreach (IList<T> list in collection)
                Add(list);
        }

        #endregion AddRange Overloads

        #region ConvertAll Overloads

        public List<TOutput> ConvertAll<TOutput>(Converter<T, TOutput> converter)
        {
            List<TOutput> _outList = new List<TOutput>();
            ConvertAll(this, _outList, converter);
            return _outList;
        }

        private void ConvertAll<TOutput>(IEnumerable inList, List<TOutput> outList, Converter<T, TOutput> converter)
        {
            foreach (object item in inList)
            {
                if (item is IEnumerable)
                    ConvertAll(item as IEnumerable, outList, converter);
                else
                    outList.Add(converter((T)item));
            }
        }

        #endregion ConvertAll Overloads

        #region CopyTo Overloads

        public void CopyTo(T[] array)
        {
            this.CopyTo(array, 0);
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            CopyTo(0, array, arrayIndex, Int32.MinValue);
        }

        public void CopyTo(int startIndex, T[] array, int arrayIndex, int count)
        {
            ChoGuard.ArgumentNotNull(array, "Destination array can't be null.");

            int listCount = Count;
            if (count == Int32.MinValue) count = listCount - startIndex;

            CheckRange(startIndex, count, listCount);

            int arrayLength = array.Length;
            if (arrayIndex < 0 || arrayIndex > arrayLength)
                throw new IndexOutOfRangeException("Destination array index is outside the bound of array.");

            int index = 0;
            int maxIndex = startIndex + count;

            foreach (T item in this)
            {
                if (index >= maxIndex) break;
                if (arrayIndex >= arrayLength) break;

                if (index >= startIndex)
                    array[arrayIndex++] = item;
                else
                    index++;
            }

            //Array.Copy(ToArray(), startIndex, array, arrayIndex, count);
        }

        #endregion CopyTo Overloads

        #region Exists Overloads

        public bool Exists(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");
            return FindIndex(match) != -1;
        }

        public bool Exists(T item)
        {
            return IndexOf(item) != -1;
        }

        #endregion Exists Overloads

        #region Find Overloads

        public T Find(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");

            foreach (T item in this)
            {
                if (match(item))
                    return item;
            }

            return default(T);
        }

        #endregion Find Overloads

        #region FindAll Overloads

        public List<T> FindAll(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");

            List<T> outList = new List<T>();
            foreach (T item in this)
            {
                if (match(item))
                    outList.Add((T)item);
            }

            return outList;
        }

        #endregion FindAll Overloads

        #region FindIndex Overloads

        public int FindIndex(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");
            return FindIndex(0, match);
        }

        public int FindIndex(int startIndex, Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");
            CheckIndex(startIndex);
            return FindIndex(startIndex, Int32.MinValue, match);
        }

        public int FindIndex(int startIndex, int count, Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");

            int listCount = Count;
            if (count == Int32.MinValue) count = listCount - startIndex;

            CheckRange(startIndex, count, listCount);

            int index = 0;
            int maxIndex = startIndex + count;
            foreach (T item in this)
            {
                if (index >= maxIndex) break;

                if (index >= startIndex && match(item))
                    return index;
                else
                    index++;
            }

            return -1;
        }

        #endregion FindIndex Overloads

        #region FindLast Overloads

        public T FindLast(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");

            foreach (T item in ReverseList())
            {
                if (match(item))
                    return item;
            }

            return default(T);
        }

        #endregion FindLast Overloads

        #region FindLastIndex Overloads

        public int FindLastIndex(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");
            return FindLastIndex(0, match);
        }

        public int FindLastIndex(int startIndex, Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");
            CheckIndex(startIndex);
            return FindLastIndex(startIndex, Int32.MinValue, match);
        }

        public int FindLastIndex(int startIndex, int count, Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");

            int listCount = Count;
            if (count == Int32.MinValue) count = listCount - startIndex;

            CheckRange(startIndex, count, listCount);

            int index = listCount - 1;
            int maxIndex = startIndex + count;
            foreach (T item in ReverseList())
            {
                if (index < startIndex) break;

                if (index < maxIndex && match(item))
                    return index;
                else
                    index--;
            }

            return -1;
        }

        #endregion FindLastIndex Overloads

        #region IndexOf Overloads

        public int IndexOf(T item)
        {
            return IndexOf(item, 0);
        }

        public int IndexOf(T item, int startIndex)
        {
            CheckIndex(startIndex);
            return IndexOf(item, startIndex, Int32.MinValue);
        }

        public int IndexOf(T item, int startIndex, int count)
        {
            int listCount = Count;
            if (count == Int32.MinValue) count = listCount - startIndex;

            CheckRange(startIndex, count, listCount);

            int index = 0;
            int maxIndex = startIndex + count;
            foreach (T item1 in this)
            {
                if (index >= maxIndex) break;

                if (index >= startIndex && EqualityComparer<T>.Default.Equals(item, item1))
                    return index;
                else
                    index++;
            }

            return -1;
        }

        #endregion IndexOf Overloads

        #region InsertRange Overloads

        public void InsertRange(int index, IEnumerable<T> collection)
        {
            ChoGuard.ArgumentNotNull(collection, "collection");
            CheckIndex(index);

            foreach (T item in collection)
                Insert(index, item);
        }

        public void InsertRange(int index, IEnumerable<IList<T>> collection)
        {
            ChoGuard.ArgumentNotNull(collection, "collection");
            CheckIndex(index);

            foreach (IList<T> item in collection)
                Insert(index, item);
        }

        #endregion InsertRange Overloads

        #region GetRange Overloads

        public List<T> GetRange(int index, int count)
        {
            CheckRange(index, count, Count);

            T[] tmpArray = new T[count];
            CopyTo(index, tmpArray, 0, count);

            return new List<T>(tmpArray);
        }

        #endregion GetRange Overloads

        #region RemoveRange Overloads

        public void RemoveRange(int index, int count)
        {
            CheckRange(index, count, Count);

            int counter = 0;
            RemoveRange(this, index, count, ref counter);
        }

        private void RemoveRange(IEnumerable inList, int startIndex, int count, ref int counter)
        {
            int index = 0;
            List<int> itemsTobeRemoved = new List<int>();
            List<IList<T>> emptyListsTobeRemoved = new List<IList<T>>();

            if (inList is ChoNestedList<T>)
                inList = ((ChoNestedList<T>)inList)._innerList;

            foreach (object item in inList)
            {
                if (item is IEnumerable)
                {
                    RemoveRange(item as IEnumerable, startIndex, count, ref counter);
                    if (item is ICollection && ((ICollection)item).Count == 0
                        || item is ICollection<T> && ((ICollection<T>)item).Count == 0)
                        emptyListsTobeRemoved.Add((IList<T>)item);
                }
                else
                {
                    if (counter >= startIndex && startIndex + count > counter)
                        itemsTobeRemoved.Add(index);
                    counter++;
                }
                index++;
            }
            RemoveItemsAt(inList, itemsTobeRemoved, emptyListsTobeRemoved);
        }

        #endregion RemoveRange Overloads

        #region ForEach Overloads

        public void ForEach(Action<T> action)
        {
            ChoGuard.ArgumentNotNull(action, "action");

            foreach (T item in this)
                action(item);
        }

        #endregion ForEach Overloads

        #region LastIndexOf Overloads

        public int LastIndexOf(T item)
        {
            return LastIndexOf(item, 0);
        }

        public int LastIndexOf(T item, int startIndex)
        {
            return LastIndexOf(item, startIndex, Int32.MinValue);
        }

        public int LastIndexOf(T item, int startIndex, int count)
        {
            int listCount = Count;
            if (count == Int32.MinValue) count = listCount - startIndex;

            CheckRange(startIndex, count, listCount);

            int index = listCount - 1;
            int maxIndex = startIndex + count;
            foreach (T item1 in ReverseList())
            {
                if (index < startIndex) break;

                if (index < maxIndex && EqualityComparer<T>.Default.Equals(item, item1))
                    return index;
                else
                    index--;
            }

            return -1;
        }

        #endregion LastIndexOf Overloads

        #region Reverse Overloads

        public void Reverse()
        {
            Reverse(this);
        }

        public void Reverse(int startIndex, int count)
        {
            throw new NotSupportedException();
        }

        private void Reverse(IEnumerable inList)
        {
            if (inList is ChoNestedList<T>)
                inList = ((ChoNestedList<T>)inList)._innerList;

            foreach (object item in inList)
            {
                if (item is IEnumerable)
                    Reverse(item as IEnumerable);
            }

            if (inList is ArrayList)
                ((ArrayList)inList).Reverse();
            else if (inList is ChoNestedList<T>)
                ((ChoNestedList<T>)inList)._innerList.Reverse();
            else if (inList is List<T>)
                ((List<T>)inList).Reverse();
            else
				throw new ChoNestedListException("Unsupported list item found.");
		}

        #endregion Reverse Overloads

        #region RemoveAll Overloads

        public int RemoveAll(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");

            int counter = -1;
            RemoveAll(this, match, ref counter);

            return counter == -1 ? 0 : counter;
        }

        private void RemoveAll(IEnumerable inList, Predicate<T> match, ref int counter)
        {
            int index = -1;
            List<int> itemsTobeRemoved = new List<int>();
            List<IList<T>> emptyListsTobeRemoved = new List<IList<T>>();

            if (inList is ChoNestedList<T>)
                inList = ((ChoNestedList<T>)inList)._innerList;

            foreach (object item in inList)
            {
                index++;

                if (item == null || item is T)
                {
                    counter++;

                    if (match((T)item))
                        itemsTobeRemoved.Add(index);
                }
                else if (item is IEnumerable)
                {
                    RemoveAll((IEnumerable)item, match, ref counter);
                    if (item is ICollection && ((ICollection)item).Count == 0
                        || item is ICollection<T> && ((ICollection<T>)item).Count == 0)
                        emptyListsTobeRemoved.Add((IList<T>)item);
                }
                else
					throw new ChoNestedListException("Unsupported list item found.");
			}

            RemoveItemsAt(inList, itemsTobeRemoved, emptyListsTobeRemoved);
        }

        #endregion RemoveAll Overloads

        #region ToArray Overloads

        public T[] ToArray()
        {
            List<T> list = new List<T>();
            ToArray(_innerList, list);
            return list.ToArray();
        }

        #endregion ToArray Overloads

        #region TrimExcess Overloads

        public void TrimExcess()
        {
            TrimExcess(this);
        }
        
        private void TrimExcess(IEnumerable inList)
        {
            if (inList is ChoNestedList<T>)
                inList = ((ChoNestedList<T>)inList)._innerList;

            if (inList is ArrayList)
                ((ArrayList)inList).TrimToSize();
            else if (inList is ChoNestedList<T>)
                ((ChoNestedList<T>)inList)._innerList.TrimToSize();
            else if (inList is List<T>)
                ((List<T>)inList).TrimExcess();

            foreach (object item in inList)
            {
                if (item is IEnumerable)
                    TrimExcess(item as IEnumerable);
            }
        }

        #endregion TrimExcess Overloads

        #region TrueForAll Overloads

        public bool TrueForAll(Predicate<T> match)
        {
            ChoGuard.ArgumentNotNull(match, "match");

            foreach (T item in this)
            {
                if (!match((T)item))
                    return false;
            }

            return true;
        }

        #endregion TrueForAll Overloads

        #region Instance Properties (Public)

        public bool IsFixedSize
        {
            get { return false; }
        }

        public bool IsNotNullable
        {
            get { return false; }
        }

        public bool IsSynchronized
        {
            get { return false; }
        }

        public bool IsUnique
        {
            get { return false; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public object SyncRoot
        {
            get { return _syncRoot; }
        }

        #endregion Instance Properties (Public)

        #endregion

        #region IList<T> Members

        #region Insert Overloads (Public)

        public void Insert(int index, T item)
        {
            _innerList.Insert(index, item);
        }

        public void Insert(int index, IList<T> item)
        {
            _innerList.Insert(index, item);
        }

        #endregion Insert Overloads (Public)

        #region RemoveAt Overloads

        public void RemoveAt(int index)
        {
            CheckIndex(index);

            int counter = 0;
            RemoveAt(this, index, ref counter);
        }

        private bool RemoveAt(IEnumerable inList, int index, ref int counter)
        {
            int listIndex = 0;
            bool found = false;
            bool foundNRemoved = false;

            foreach (object item in inList)
            {
                if (foundNRemoved) break;

                if (item is IEnumerable)
                {
                    foundNRemoved = RemoveAt(item as IEnumerable, index, ref counter);
                    if (foundNRemoved) return true;
                }
                else
                {
                    if (counter == index)
                    {
                        found = true;
                        break;
                    }
                    counter++;
                }
                listIndex++;
            }

            if (found && listIndex >= 0)
            {
                RemoveItemAt(inList, listIndex);
                return true;
            }
            else
                return false;
        }

        #endregion RemoveAt Overloads

        #region Indexer

        public T this[int index]
        {
            get
            {
                CheckIndex(index);

                int counter = 0;
                foreach (T item in this)
                {
                    if (counter == index) return item;
                    counter++;
                }

                return default(T);
            }
            set
            {
                CheckIndex(index);
                
                int counter = 0;
                SetItemAt(this, index, value, ref counter);
            }
        }

        private bool SetItemAt(IEnumerable inList, int index, T value, ref int counter)
        {
            if (inList is ChoNestedList<T>)
                inList = ((ChoNestedList<T>)inList)._innerList;

            bool found = false;
            int listIndex = 0;
            foreach (object item in inList)
            {
                if (item is IEnumerable)
                {
                    if (SetItemAt(item as IEnumerable, index, value, ref counter))
                        return true;
                }
                else
                {
                    if (counter == index)
                    {
                        found = true;
                        break;
                    }

                    counter++;
                }
                listIndex++;
            }

            if (found)
            {
                if (inList is ArrayList)
                    ((ArrayList)inList)[listIndex] = value;
                else if (inList is ChoNestedList<T>)
                    ((ChoNestedList<T>)inList)[listIndex] = value;
                else if (inList is List<T>)
                    ((List<T>)inList)[listIndex] = value;
                else
					throw new ChoNestedListException("Unsupported list item found.");
			}

            return found;
        }

        #endregion Indexer

        #endregion

        #region ICollection<T> Members

        #region Clear Overloads

        public void Clear()
        {
            _innerList.Clear();
        }

        #endregion Clear Overloads

        #region Contains Overloads

        public bool Contains(T item)
        {
            return IndexOf(item) >= 0;
        }

        public bool Contains(IList<T> listItem)
        {
            ChoGuard.ArgumentNotNull(listItem, "listItem");

            return Contains(this, listItem);
        }

        private bool Contains(IEnumerable inList, IList<T> listItem)
        {
            if (inList is ChoNestedList<T>)
                inList = ((ChoNestedList<T>)inList)._innerList;

            foreach (object item in inList)
            {
                if (item is IEnumerable)
                {
                    if (item == listItem) return true;
                    if (Contains((IEnumerable)item, listItem))
                        return true;
                }
            }

            return false;
        }

        #endregion Contains Overloads

        #region Count Method

        public int Count
        {
            get
            {
                int counter = 0;

                foreach (object item in _innerList)
                    counter += GetCount(item);

                return counter;
            }
        }

        private int GetCount(object listItem)
        {
            int count = 0;

            if (listItem is ICollection)
                return ((ICollection)listItem).Count;
            else if (listItem is ICollection<T>)
                return ((ICollection<T>)listItem).Count;
            else if (listItem is IEnumerable)
            {
                foreach (object item in (IEnumerable)listItem)
                {
                    if (item is IEnumerable)
                        count += GetCount((IEnumerable)item);
                    else
                        count++;
                }
                return count;
            }
            else
                return 1;
        }

        #endregion Count Method

		#region Remove Overloads

		public bool Remove(T item)
        {
            return Remove(this, item);
        }

		private bool Remove(IEnumerable inList, T item1)
		{
			bool found = false;
			int listIndex = -1;
			List<IList<T>> emptyListsTobeRemoved = new List<IList<T>>();

			if (inList is ChoNestedList<T>)
				inList = ((ChoNestedList<T>)inList)._innerList;

			foreach (object item in inList)
			{
				listIndex++;
				if (item is IEnumerable)
				{
					found = Remove(item as IEnumerable, item1);
					if (found)
					{
						if (item is ICollection && ((ICollection)item).Count == 0
							|| item is ICollection<T> && ((ICollection<T>)item).Count == 0)
						{
							emptyListsTobeRemoved.Add((IList<T>)item);
							RemoveEmptyLists(inList, emptyListsTobeRemoved);
						}
						return true;
					}
				}
				else
				{
					if (EqualityComparer<T>.Default.Equals((T)item1, (T)item))
					{
						found = true;
						break;
					}
				}
			}

			if (found && listIndex >= 0)
			{
				RemoveItemAt(inList, listIndex);
				return true;
			}
			else
				return false;
		}

		public bool Remove(IList<T> list)
		{
			ChoGuard.ArgumentNotNull(list, "list");

			if (list == this)
				throw new InvalidOperationException("Can't remove itself.");

			return RemoveList(_innerList, list);
		}

		private bool RemoveList(IEnumerable inList, IList<T> listItem)
		{
			bool found = false;
			int listIndex = -1;

			if (inList is ChoNestedList<T>)
				inList = ((ChoNestedList<T>)inList)._innerList;

			foreach (object item in inList)
			{
				listIndex++;
				if (item is IEnumerable)
				{
					if (Object.Equals(item, listItem))
					{
						found = true;
						break;
					}

					found = RemoveList(item as IEnumerable, listItem);
					if (found)
						return true;
				}
			}

			if (found && listIndex >= 0)
			{
				RemoveItemAt(inList, listIndex);
				return true;
			}
			else
				return false;
		}

		#endregion Remove Overloads

		#endregion

		#region IEnumerable<T> Members

		public IEnumerator<T> GetEnumerator()
        {
            return new ChoNestedCollectionEnumerator<T>(_innerList);
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return new ChoNestedCollectionEnumerator<T>(_innerList);
        }

        #endregion

        #region GetListItemAt Overloads

        public IList<T> GetListItemAt(int index)
        {
            CheckIndex(index);

            int counter = 0;
            return GetContainedListItemAt(this, index, ref counter);
        }

		private IList<T> GetContainedListItemAt(IEnumerable inList, int index, ref int counter)
		{
			IEnumerable sourceList = inList;

			if (inList is ChoNestedList<T>)
				inList = ((ChoNestedList<T>)inList)._innerList;

			foreach (object item in inList)
			{
				if (index == counter)
				{
					if (item is IEnumerable)
						return item as IList<T>;
					else
						return sourceList as IList<T>;
				}

				if (item is IEnumerable)
				{
					IList<T> found = GetContainedListItemAt(item as IEnumerable, index, ref counter);
					if (found != null)
						return found;
					else
						continue;
				}
				counter++;
			}

			return null;
		}

		#endregion GetListItemAt Overloads

		#region BinarySearch Overloads

		public static int BinarySearch(T[] array, T item)
        {
            return Array.BinarySearch<T>(array, 0, array.Length, item);
        }

        public static int BinarySearch(T[] array, T item, IComparer<T> comparer)
        {
            return Array.BinarySearch<T>(array, 0, array.Length, item, comparer);
        }

        public static int BinarySearch(T[] array, int index, int count, T item, IComparer<T> comparer)
        {
            CheckRange(index, count, array.Length);
            return Array.BinarySearch<T>(array, index, count, item, comparer);
		}

		#endregion BinarySearch Overloads

		#region Shared Members (Private)

		private static void CheckRange(int idx, int count, int size)
        {
            if (idx < 0)
                throw new ArgumentOutOfRangeException("index");

            if (count < 0)
                throw new ArgumentOutOfRangeException("count");

            if ((uint)idx + (uint)count > (uint)size)
                throw new ArgumentException("index and count exceed length of list");
        }

        #endregion Shared Members (Private)

        #region Instance Members (Private)

        private void CheckIndex(int index)
        {
            if (index < 0 || (uint)index >= (uint)Count)
                throw new ArgumentOutOfRangeException("index");
        }

        private IEnumerable<T> ReverseList()
        {
            for (int i = Count - 1; i >= 0; i--)
                yield return this[i];
        }

        private static void RemoveItemsAt(IEnumerable inList, IEnumerable<int> itemsTobeRemoved, List<IList<T>> emptyListsTobeRemoved)
        {
            if (inList is ChoNestedList<T>)
            {
                foreach (int index1 in itemsTobeRemoved.Reverse())
                    ((ChoNestedList<T>)inList).RemoveAt(index1);
            }
            else if (inList is IList)
            {
                foreach (int index1 in itemsTobeRemoved.Reverse())
                    ((IList)inList).RemoveAt(index1);
            }
            else if (inList is IList<T>)
            {
                foreach (int index1 in itemsTobeRemoved.Reverse())
                    ((IList<T>)inList).RemoveAt(index1);
            }

			RemoveEmptyLists(inList, emptyListsTobeRemoved);
        }

		private static void RemoveItemAt(IEnumerable inList, int index)
		{
			if (index < 0)
				return;

			if (inList is IList)
				((IList)inList).RemoveAt(index);
			else if (inList is ChoNestedList<T>)
				((ChoNestedList<T>)inList)._innerList.RemoveAt(index);
			else if (inList is IList<T>)
				((IList<T>)inList).RemoveAt(index);
			else
				throw new ChoNestedListException("Unsupported list item found.");
		}

		private static void RemoveEmptyLists(IEnumerable inList, List<IList<T>> emptyListsTobeRemoved)
		{
			if (emptyListsTobeRemoved != null)
			{
				emptyListsTobeRemoved.Reverse();
				foreach (IList<T> item in emptyListsTobeRemoved)
				{
					((IList)inList).Remove(item);
				}
			}
		}

        private void ToArray(IEnumerable inList, List<T> list)
        {
            foreach (object item in inList)
            {
                if (item is IEnumerable)
                    ToArray(item as IEnumerable, list);
                else
                    list.Add((T)item);
            }
        }

        #endregion Instance Members (Private)

        #region ChoNestedCollectionEnumerator Class

        // Synchronized list iterator.
        private sealed class ChoNestedCollectionEnumerator<T1> : ChoSyncDisposableObject, IEnumerator<T1>
        {
            #region Instance Data Members (Private)

            private Stack<IEnumerator> _collectionStack = new Stack<IEnumerator>();
            private T1 _current;

            #endregion Instance Data Members (Private)

            #region Constructors

            // Constructor.
            public ChoNestedCollectionEnumerator(ICollection collection)
            {
                ChoGuard.ArgumentNotNull(collection, "Collection");
                _collectionStack.Push(collection.GetEnumerator());
            }

            #endregion Constructors

            #region ChoSyncDisposableObject Overrides

            protected override void Dispose(bool finalize)
            {
            }

            #endregion ChoSyncDisposableObject Overrides

            #region IEnumerator<T1> Members

            public T1 Current
            {
                get { return _current; }
            }

            #endregion

            #region IEnumerator Members

            object System.Collections.IEnumerator.Current
            {
                get { return _current; }
            }

            public bool MoveNext()
            {
                return Move2NextItem();
            }

            public void Reset()
            {
                foreach (IEnumerator<T1> collection in _collectionStack)
                    collection.Reset();

                _collectionStack.Clear();
            }

            #endregion

            #region Instance Members (Private)

            private bool Move2NextItem()
            {
                if (_collectionStack.Count == 0)
                {
                    _current = default(T1);
                    return false;
                }
                else
                    return Move2NextItem(_collectionStack.Peek());
            }

            private bool Move2NextItem(IEnumerator collection)
            {
                bool retVal = collection.MoveNext();
                if (!retVal)
                {
                    _collectionStack.Pop();
                    return Move2NextItem();
                }
                else
                {
                    if (collection.Current is IEnumerable)
                    {
                        _collectionStack.Push(((IEnumerable)collection.Current).GetEnumerator());
                        return Move2NextItem();
                    }
                    else
                        _current = (T1)collection.Current;
                }

                return retVal;
            }

            #endregion Instance Members (Private)

        };

        #endregion ChoNestedCollectionEnumerator Class

		#region ChoNestedCollectionListEnumerator Class

		// Synchronized list iterator.
        public sealed class ChoNestedCollectionListEnumerator<T1> : ChoSyncDisposableObject, IEnumerator<ChoNestedList<T1>>
        {
            #region Instance Data Members (Private)

			private Stack<IEnumerator> _collectionStack = new Stack<IEnumerator>();
			private ChoNestedList<T1> _current;

            #endregion Instance Data Members (Private)

            #region Constructors

            // Constructor.
			public ChoNestedCollectionListEnumerator(ChoNestedList<T1> collection)
            {
                ChoGuard.ArgumentNotNull(collection, "Collection");
                _collectionStack.Push(collection._innerList.GetEnumerator());
            }

            #endregion Constructors

            #region ChoSyncDisposableObject Overrides

            protected override void Dispose(bool finalize)
            {
            }

            #endregion ChoSyncDisposableObject Overrides

            #region IEnumerator<T1> Members

			public ChoNestedList<T1> Current
            {
                get { return _current; }
            }

            #endregion

            #region IEnumerator Members

            object System.Collections.IEnumerator.Current
            {
                get { return _current; }
            }

            public bool MoveNext()
            {
                return Move2NextItem();
            }

            public void Reset()
            {
                foreach (IEnumerator<T1> collection in _collectionStack)
                    collection.Reset();

                _collectionStack.Clear();
            }


            #endregion

            #region Instance Members (Private)

            private bool Move2NextItem()
            {
                if (_collectionStack.Count == 0)
                {
					_current = default(ChoNestedList<T1>);
                    return false;
                }
                else
                    return Move2NextItem(_collectionStack.Peek());
            }

			private bool Move2NextItem(IEnumerator collection)
            {
                bool retVal = false;

                while (true)
                {
                    if (!collection.MoveNext())
                        break;

					if (collection.Current is ChoNestedList<T1>)
                    {
                        retVal = true;
						_current = (ChoNestedList<T1>)collection.Current;
						_collectionStack.Push(((IEnumerable)collection.Current).GetEnumerator());
						break;
                    }
                }

                if (!retVal)
                {
                    _collectionStack.Pop();
                    return Move2NextItem();
                }
				//else
				//{
				//    if (collection.Current is ChoNestedList<T1>)
				//    {
				//        _collectionStack.Push(((IEnumerable)collection.Current).GetEnumerator());
				//        return Move2NextItem();
				//    }
				//    else
				//        _current = (ChoNestedList<T1>)collection.Current;
				//}

                return retVal;
            }

            #endregion Instance Members (Private)

        };

		#endregion ChoNestedCollectionListEnumerator Class
	}
}